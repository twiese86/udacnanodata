
# Prosper Loan Data
## by Thomas Wiese

## Preliminary Wrangling

I'm interested in exploring defaults


```python
# import all packages and set plots to be embedded inline
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

%matplotlib inline
```

> Load in your dataset and describe its properties through the questions below.
Try and motivate your exploration goals through this section.


```python
df = pd.read_csv('prosperLoanData.csv')
pd.set_option("display.max_columns", len(df.columns))

```


```python
df.info()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 113937 entries, 0 to 113936
    Data columns (total 81 columns):
    ListingKey                             113937 non-null object
    ListingNumber                          113937 non-null int64
    ListingCreationDate                    113937 non-null object
    CreditGrade                            28953 non-null object
    Term                                   113937 non-null int64
    LoanStatus                             113937 non-null object
    ClosedDate                             55089 non-null object
    BorrowerAPR                            113912 non-null float64
    BorrowerRate                           113937 non-null float64
    LenderYield                            113937 non-null float64
    EstimatedEffectiveYield                84853 non-null float64
    EstimatedLoss                          84853 non-null float64
    EstimatedReturn                        84853 non-null float64
    ProsperRating (numeric)                84853 non-null float64
    ProsperRating (Alpha)                  84853 non-null object
    ProsperScore                           84853 non-null float64
    ListingCategory (numeric)              113937 non-null int64
    BorrowerState                          108422 non-null object
    Occupation                             110349 non-null object
    EmploymentStatus                       111682 non-null object
    EmploymentStatusDuration               106312 non-null float64
    IsBorrowerHomeowner                    113937 non-null bool
    CurrentlyInGroup                       113937 non-null bool
    GroupKey                               13341 non-null object
    DateCreditPulled                       113937 non-null object
    CreditScoreRangeLower                  113346 non-null float64
    CreditScoreRangeUpper                  113346 non-null float64
    FirstRecordedCreditLine                113240 non-null object
    CurrentCreditLines                     106333 non-null float64
    OpenCreditLines                        106333 non-null float64
    TotalCreditLinespast7years             113240 non-null float64
    OpenRevolvingAccounts                  113937 non-null int64
    OpenRevolvingMonthlyPayment            113937 non-null float64
    InquiriesLast6Months                   113240 non-null float64
    TotalInquiries                         112778 non-null float64
    CurrentDelinquencies                   113240 non-null float64
    AmountDelinquent                       106315 non-null float64
    DelinquenciesLast7Years                112947 non-null float64
    PublicRecordsLast10Years               113240 non-null float64
    PublicRecordsLast12Months              106333 non-null float64
    RevolvingCreditBalance                 106333 non-null float64
    BankcardUtilization                    106333 non-null float64
    AvailableBankcardCredit                106393 non-null float64
    TotalTrades                            106393 non-null float64
    TradesNeverDelinquent (percentage)     106393 non-null float64
    TradesOpenedLast6Months                106393 non-null float64
    DebtToIncomeRatio                      105383 non-null float64
    IncomeRange                            113937 non-null object
    IncomeVerifiable                       113937 non-null bool
    StatedMonthlyIncome                    113937 non-null float64
    LoanKey                                113937 non-null object
    TotalProsperLoans                      22085 non-null float64
    TotalProsperPaymentsBilled             22085 non-null float64
    OnTimeProsperPayments                  22085 non-null float64
    ProsperPaymentsLessThanOneMonthLate    22085 non-null float64
    ProsperPaymentsOneMonthPlusLate        22085 non-null float64
    ProsperPrincipalBorrowed               22085 non-null float64
    ProsperPrincipalOutstanding            22085 non-null float64
    ScorexChangeAtTimeOfListing            18928 non-null float64
    LoanCurrentDaysDelinquent              113937 non-null int64
    LoanFirstDefaultedCycleNumber          16952 non-null float64
    LoanMonthsSinceOrigination             113937 non-null int64
    LoanNumber                             113937 non-null int64
    LoanOriginalAmount                     113937 non-null int64
    LoanOriginationDate                    113937 non-null object
    LoanOriginationQuarter                 113937 non-null object
    MemberKey                              113937 non-null object
    MonthlyLoanPayment                     113937 non-null float64
    LP_CustomerPayments                    113937 non-null float64
    LP_CustomerPrincipalPayments           113937 non-null float64
    LP_InterestandFees                     113937 non-null float64
    LP_ServiceFees                         113937 non-null float64
    LP_CollectionFees                      113937 non-null float64
    LP_GrossPrincipalLoss                  113937 non-null float64
    LP_NetPrincipalLoss                    113937 non-null float64
    LP_NonPrincipalRecoverypayments        113937 non-null float64
    PercentFunded                          113937 non-null float64
    Recommendations                        113937 non-null int64
    InvestmentFromFriendsCount             113937 non-null int64
    InvestmentFromFriendsAmount            113937 non-null float64
    Investors                              113937 non-null int64
    dtypes: bool(3), float64(50), int64(11), object(17)
    memory usage: 68.1+ MB
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ListingKey</th>
      <th>ListingNumber</th>
      <th>ListingCreationDate</th>
      <th>CreditGrade</th>
      <th>Term</th>
      <th>LoanStatus</th>
      <th>ClosedDate</th>
      <th>BorrowerAPR</th>
      <th>BorrowerRate</th>
      <th>LenderYield</th>
      <th>EstimatedEffectiveYield</th>
      <th>EstimatedLoss</th>
      <th>EstimatedReturn</th>
      <th>ProsperRating (numeric)</th>
      <th>ProsperRating (Alpha)</th>
      <th>ProsperScore</th>
      <th>ListingCategory (numeric)</th>
      <th>BorrowerState</th>
      <th>Occupation</th>
      <th>EmploymentStatus</th>
      <th>EmploymentStatusDuration</th>
      <th>IsBorrowerHomeowner</th>
      <th>CurrentlyInGroup</th>
      <th>GroupKey</th>
      <th>DateCreditPulled</th>
      <th>CreditScoreRangeLower</th>
      <th>CreditScoreRangeUpper</th>
      <th>FirstRecordedCreditLine</th>
      <th>CurrentCreditLines</th>
      <th>OpenCreditLines</th>
      <th>TotalCreditLinespast7years</th>
      <th>OpenRevolvingAccounts</th>
      <th>OpenRevolvingMonthlyPayment</th>
      <th>InquiriesLast6Months</th>
      <th>TotalInquiries</th>
      <th>CurrentDelinquencies</th>
      <th>AmountDelinquent</th>
      <th>DelinquenciesLast7Years</th>
      <th>PublicRecordsLast10Years</th>
      <th>PublicRecordsLast12Months</th>
      <th>RevolvingCreditBalance</th>
      <th>BankcardUtilization</th>
      <th>AvailableBankcardCredit</th>
      <th>TotalTrades</th>
      <th>TradesNeverDelinquent (percentage)</th>
      <th>TradesOpenedLast6Months</th>
      <th>DebtToIncomeRatio</th>
      <th>IncomeRange</th>
      <th>IncomeVerifiable</th>
      <th>StatedMonthlyIncome</th>
      <th>LoanKey</th>
      <th>TotalProsperLoans</th>
      <th>TotalProsperPaymentsBilled</th>
      <th>OnTimeProsperPayments</th>
      <th>ProsperPaymentsLessThanOneMonthLate</th>
      <th>ProsperPaymentsOneMonthPlusLate</th>
      <th>ProsperPrincipalBorrowed</th>
      <th>ProsperPrincipalOutstanding</th>
      <th>ScorexChangeAtTimeOfListing</th>
      <th>LoanCurrentDaysDelinquent</th>
      <th>LoanFirstDefaultedCycleNumber</th>
      <th>LoanMonthsSinceOrigination</th>
      <th>LoanNumber</th>
      <th>LoanOriginalAmount</th>
      <th>LoanOriginationDate</th>
      <th>LoanOriginationQuarter</th>
      <th>MemberKey</th>
      <th>MonthlyLoanPayment</th>
      <th>LP_CustomerPayments</th>
      <th>LP_CustomerPrincipalPayments</th>
      <th>LP_InterestandFees</th>
      <th>LP_ServiceFees</th>
      <th>LP_CollectionFees</th>
      <th>LP_GrossPrincipalLoss</th>
      <th>LP_NetPrincipalLoss</th>
      <th>LP_NonPrincipalRecoverypayments</th>
      <th>PercentFunded</th>
      <th>Recommendations</th>
      <th>InvestmentFromFriendsCount</th>
      <th>InvestmentFromFriendsAmount</th>
      <th>Investors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1021339766868145413AB3B</td>
      <td>193129</td>
      <td>2007-08-26 19:09:29.263000000</td>
      <td>C</td>
      <td>36</td>
      <td>Completed</td>
      <td>2009-08-14 00:00:00</td>
      <td>0.16516</td>
      <td>0.1580</td>
      <td>0.1380</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>CO</td>
      <td>Other</td>
      <td>Self-employed</td>
      <td>2.0</td>
      <td>True</td>
      <td>True</td>
      <td>NaN</td>
      <td>2007-08-26 18:41:46.780000000</td>
      <td>640.0</td>
      <td>659.0</td>
      <td>2001-10-11 00:00:00</td>
      <td>5.0</td>
      <td>4.0</td>
      <td>12.0</td>
      <td>1</td>
      <td>24.0</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>472.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>1500.0</td>
      <td>11.0</td>
      <td>0.81</td>
      <td>0.0</td>
      <td>0.17</td>
      <td>$25,000-49,999</td>
      <td>True</td>
      <td>3083.333333</td>
      <td>E33A3400205839220442E84</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>78</td>
      <td>19141</td>
      <td>9425</td>
      <td>2007-09-12 00:00:00</td>
      <td>Q3 2007</td>
      <td>1F3E3376408759268057EDA</td>
      <td>330.43</td>
      <td>11396.14</td>
      <td>9425.00</td>
      <td>1971.14</td>
      <td>-133.18</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>258</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10273602499503308B223C1</td>
      <td>1209647</td>
      <td>2014-02-27 08:28:07.900000000</td>
      <td>NaN</td>
      <td>36</td>
      <td>Current</td>
      <td>NaN</td>
      <td>0.12016</td>
      <td>0.0920</td>
      <td>0.0820</td>
      <td>0.07960</td>
      <td>0.0249</td>
      <td>0.05470</td>
      <td>6.0</td>
      <td>A</td>
      <td>7.0</td>
      <td>2</td>
      <td>CO</td>
      <td>Professional</td>
      <td>Employed</td>
      <td>44.0</td>
      <td>False</td>
      <td>False</td>
      <td>NaN</td>
      <td>2014-02-27 08:28:14</td>
      <td>680.0</td>
      <td>699.0</td>
      <td>1996-03-18 00:00:00</td>
      <td>14.0</td>
      <td>14.0</td>
      <td>29.0</td>
      <td>13</td>
      <td>389.0</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>3989.0</td>
      <td>0.21</td>
      <td>10266.0</td>
      <td>29.0</td>
      <td>1.00</td>
      <td>2.0</td>
      <td>0.18</td>
      <td>$50,000-74,999</td>
      <td>True</td>
      <td>6125.000000</td>
      <td>9E3B37071505919926B1D82</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>0</td>
      <td>134815</td>
      <td>10000</td>
      <td>2014-03-03 00:00:00</td>
      <td>Q1 2014</td>
      <td>1D13370546739025387B2F4</td>
      <td>318.93</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0EE9337825851032864889A</td>
      <td>81716</td>
      <td>2007-01-05 15:00:47.090000000</td>
      <td>HR</td>
      <td>36</td>
      <td>Completed</td>
      <td>2009-12-17 00:00:00</td>
      <td>0.28269</td>
      <td>0.2750</td>
      <td>0.2400</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>GA</td>
      <td>Other</td>
      <td>Not available</td>
      <td>NaN</td>
      <td>False</td>
      <td>True</td>
      <td>783C3371218786870A73D20</td>
      <td>2007-01-02 14:09:10.060000000</td>
      <td>480.0</td>
      <td>499.0</td>
      <td>2002-07-27 00:00:00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.06</td>
      <td>Not displayed</td>
      <td>True</td>
      <td>2083.333333</td>
      <td>6954337960046817851BCB2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>86</td>
      <td>6466</td>
      <td>3001</td>
      <td>2007-01-17 00:00:00</td>
      <td>Q1 2007</td>
      <td>5F7033715035555618FA612</td>
      <td>123.32</td>
      <td>4186.63</td>
      <td>3001.00</td>
      <td>1185.63</td>
      <td>-24.20</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>41</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0EF5356002482715299901A</td>
      <td>658116</td>
      <td>2012-10-22 11:02:35.010000000</td>
      <td>NaN</td>
      <td>36</td>
      <td>Current</td>
      <td>NaN</td>
      <td>0.12528</td>
      <td>0.0974</td>
      <td>0.0874</td>
      <td>0.08490</td>
      <td>0.0249</td>
      <td>0.06000</td>
      <td>6.0</td>
      <td>A</td>
      <td>9.0</td>
      <td>16</td>
      <td>GA</td>
      <td>Skilled Labor</td>
      <td>Employed</td>
      <td>113.0</td>
      <td>True</td>
      <td>False</td>
      <td>NaN</td>
      <td>2012-10-22 11:02:32</td>
      <td>800.0</td>
      <td>819.0</td>
      <td>1983-02-28 00:00:00</td>
      <td>5.0</td>
      <td>5.0</td>
      <td>29.0</td>
      <td>7</td>
      <td>115.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.0</td>
      <td>10056.0</td>
      <td>14.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1444.0</td>
      <td>0.04</td>
      <td>30754.0</td>
      <td>26.0</td>
      <td>0.76</td>
      <td>0.0</td>
      <td>0.15</td>
      <td>$25,000-49,999</td>
      <td>True</td>
      <td>2875.000000</td>
      <td>A0393664465886295619C51</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>16</td>
      <td>77296</td>
      <td>10000</td>
      <td>2012-11-01 00:00:00</td>
      <td>Q4 2012</td>
      <td>9ADE356069835475068C6D2</td>
      <td>321.45</td>
      <td>5143.20</td>
      <td>4091.09</td>
      <td>1052.11</td>
      <td>-108.01</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>158</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0F023589499656230C5E3E2</td>
      <td>909464</td>
      <td>2013-09-14 18:38:39.097000000</td>
      <td>NaN</td>
      <td>36</td>
      <td>Current</td>
      <td>NaN</td>
      <td>0.24614</td>
      <td>0.2085</td>
      <td>0.1985</td>
      <td>0.18316</td>
      <td>0.0925</td>
      <td>0.09066</td>
      <td>3.0</td>
      <td>D</td>
      <td>4.0</td>
      <td>2</td>
      <td>MN</td>
      <td>Executive</td>
      <td>Employed</td>
      <td>44.0</td>
      <td>True</td>
      <td>False</td>
      <td>NaN</td>
      <td>2013-09-14 18:38:44</td>
      <td>680.0</td>
      <td>699.0</td>
      <td>2004-02-20 00:00:00</td>
      <td>19.0</td>
      <td>19.0</td>
      <td>49.0</td>
      <td>6</td>
      <td>220.0</td>
      <td>1.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6193.0</td>
      <td>0.81</td>
      <td>695.0</td>
      <td>39.0</td>
      <td>0.95</td>
      <td>2.0</td>
      <td>0.26</td>
      <td>$100,000+</td>
      <td>True</td>
      <td>9583.333333</td>
      <td>A180369302188889200689E</td>
      <td>1.0</td>
      <td>11.0</td>
      <td>11.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>11000.0</td>
      <td>9947.9</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>6</td>
      <td>102670</td>
      <td>15000</td>
      <td>2013-09-20 00:00:00</td>
      <td>Q3 2013</td>
      <td>36CE356043264555721F06C</td>
      <td>563.97</td>
      <td>2819.85</td>
      <td>1563.22</td>
      <td>1256.63</td>
      <td>-60.27</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>



1) Some variables have a lot of null values. TotalProsperLoans, for instance, and a lot of other variables associated with the Prosper history of the debtor.

2) A lot of these variables seem to be administrative identifiers (e.g. ListingKey and ListingNumber), and redundant ones at that. They won't be of much use to us. 

3) There are 17 variables of type object. Those will probably need some attention before they're ready for some of our classification models.

4) Variables have a wide variety of ranges. We will probably need to re-scale them to make them more amenable to some of our classifiers.

*Remove same null vales first


```python
categorical = df.select_dtypes(include=["object"]).columns.values
df[categorical] = df[categorical].fillna("Unknown")

df.select_dtypes(exclude=[np.number]).isnull().sum()
```




    ListingKey                 0
    ListingCreationDate        0
    CreditGrade                0
    LoanStatus                 0
    ClosedDate                 0
    ProsperRating (Alpha)      0
    BorrowerState              0
    Occupation                 0
    EmploymentStatus           0
    IsBorrowerHomeowner        0
    CurrentlyInGroup           0
    GroupKey                   0
    DateCreditPulled           0
    FirstRecordedCreditLine    0
    IncomeRange                0
    IncomeVerifiable           0
    LoanKey                    0
    LoanOriginationDate        0
    LoanOriginationQuarter     0
    MemberKey                  0
    dtype: int64



## DEAL WITH ALL THE NaN's


```python
borrower_fees = df["BorrowerAPR"] - df["BorrowerRate"]
borrower_fees.median()
```




    0.025019999999999987




```python
df["BorrowerAPR"].fillna(df["BorrowerRate"] + borrower_fees.median(), inplace=True)

df["BorrowerAPR"].isnull().sum()
# fill NaN with median APR
```




    0




```python
estimated_loss_from_fees = df["BorrowerRate"] - df["EstimatedEffectiveYield"]
estimated_loss_from_fees.median()
```




    0.01915




```python
df["EstimatedEffectiveYield"].fillna(df["BorrowerRate"] - estimated_loss_from_fees.median(), inplace=True)

df["EstimatedEffectiveYield"].isnull().sum()
#fill NaN EFY
```




    0




```python
df["EstimatedLoss"].fillna(df["EstimatedLoss"].median(), inplace=True)

df["EstimatedLoss"].isnull().sum()
# fill NaN loss
```




    0




```python
df["EstimatedReturn"].fillna(df["EstimatedEffectiveYield"] - df["EstimatedLoss"], inplace=True)

df["EstimatedReturn"].isnull().sum()
# fill NaN return
```




    0




```python
df["ProsperRating (numeric)"].fillna(df["ProsperRating (numeric)"].median(), inplace=True)
df["ProsperScore"].fillna(df["ProsperScore"].median(), inplace=True)


df["ProsperRating (numeric)"].isnull().sum(), df["ProsperScore"].isnull().sum()
# fill NaN rating, score
```




    (0, 0)




```python
df.dropna(subset=["EmploymentStatusDuration", "CreditScoreRangeLower", "FirstRecordedCreditLine", "CurrentCreditLines",
                  "TotalCreditLinespast7years"], inplace=True)
# drop NaN
```


```python
df["DebtToIncomeRatio"].fillna(df["MonthlyLoanPayment"] / (df["StatedMonthlyIncome"] + 1), inplace = True)

df["DebtToIncomeRatio"].isnull().sum()
# fill NaN debt to income
```




    0




```python
df.drop(["LoanCurrentDaysDelinquent", "LoanFirstDefaultedCycleNumber", "LoanMonthsSinceOrigination", "LP_CustomerPayments",
         "LP_CustomerPrincipalPayments", "LP_InterestandFees", "LP_ServiceFees", "LP_CollectionFees", "LP_GrossPrincipalLoss",
         "LP_NetPrincipalLoss", "LP_NonPrincipalRecoverypayments", "ListingCreationDate", "ClosedDate", "DateCreditPulled", "LoanOriginationDate", "LoanOriginationQuarter", "MemberKey", "ListingKey", "ListingNumber", "LoanKey", "LoanNumber"], axis=1, inplace=True)
# drop a bunch of usless stuff
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-163-bf10518d79f2> in <module>()
          1 df.drop(["LoanCurrentDaysDelinquent", "LoanFirstDefaultedCycleNumber", "LoanMonthsSinceOrigination", "LP_CustomerPayments",
          2          "LP_CustomerPrincipalPayments", "LP_InterestandFees", "LP_ServiceFees", "LP_CollectionFees", "LP_GrossPrincipalLoss",
    ----> 3          "LP_NetPrincipalLoss", "LP_NonPrincipalRecoverypayments", "ListingCreationDate", "ClosedDate", "DateCreditPulled", "LoanOriginationDate", "LoanOriginationQuarter", "MemberKey", "ListingKey", "ListingNumber", "LoanKey", "LoanNumber"], axis=1, inplace=True)
    

    ~\Anaconda3\lib\site-packages\pandas\core\frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3695                                            index=index, columns=columns,
       3696                                            level=level, inplace=inplace,
    -> 3697                                            errors=errors)
       3698 
       3699     @rewrite_axis_style_signature('mapper', [('copy', True),
    

    ~\Anaconda3\lib\site-packages\pandas\core\generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3109         for axis, labels in axes.items():
       3110             if labels is not None:
    -> 3111                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       3112 
       3113         if inplace:
    

    ~\Anaconda3\lib\site-packages\pandas\core\generic.py in _drop_axis(self, labels, axis, level, errors)
       3141                 new_axis = axis.drop(labels, level=level, errors=errors)
       3142             else:
    -> 3143                 new_axis = axis.drop(labels, errors=errors)
       3144             result = self.reindex(**{axis_name: new_axis})
       3145 
    

    ~\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in drop(self, labels, errors)
       4402             if errors != 'ignore':
       4403                 raise KeyError(
    -> 4404                     '{} not found in axis'.format(labels[mask]))
       4405             indexer = indexer[~mask]
       4406         return self.delete(indexer)
    

    KeyError: "['LoanCurrentDaysDelinquent' 'LoanFirstDefaultedCycleNumber'\n 'LoanMonthsSinceOrigination' 'LP_CustomerPayments'\n 'LP_CustomerPrincipalPayments' 'LP_InterestandFees' 'LP_ServiceFees'\n 'LP_CollectionFees' 'LP_GrossPrincipalLoss' 'LP_NetPrincipalLoss'\n 'LP_NonPrincipalRecoverypayments' 'ListingCreationDate' 'ClosedDate'\n 'DateCreditPulled' 'LoanOriginationDate' 'LoanOriginationQuarter'\n 'MemberKey' 'ListingKey' 'ListingNumber' 'LoanKey' 'LoanNumber'] not found in axis"



```python
prosper_vars = ["TotalProsperLoans","TotalProsperPaymentsBilled", "OnTimeProsperPayments", "ProsperPaymentsLessThanOneMonthLate",
                "ProsperPaymentsOneMonthPlusLate", "ProsperPrincipalBorrowed", "ProsperPrincipalOutstanding"]

df[prosper_vars] = df[prosper_vars].fillna(0)

df.isnull().sum()

```




    CreditGrade                            0
    Term                                   0
    LoanStatus                             0
    BorrowerAPR                            0
    BorrowerRate                           0
    LenderYield                            0
    EstimatedEffectiveYield                0
    EstimatedLoss                          0
    EstimatedReturn                        0
    ProsperRating (numeric)                0
    ProsperRating (Alpha)                  0
    ProsperScore                           0
    ListingCategory (numeric)              0
    BorrowerState                          0
    Occupation                             0
    EmploymentStatus                       0
    EmploymentStatusDuration               0
    IsBorrowerHomeowner                    0
    CurrentlyInGroup                       0
    GroupKey                               0
    CreditScoreRangeLower                  0
    CreditScoreRangeUpper                  0
    FirstRecordedCreditLine                0
    CurrentCreditLines                     0
    OpenCreditLines                        0
    TotalCreditLinespast7years             0
    OpenRevolvingAccounts                  0
    OpenRevolvingMonthlyPayment            0
    InquiriesLast6Months                   0
    TotalInquiries                         0
    CurrentDelinquencies                   0
    AmountDelinquent                       0
    DelinquenciesLast7Years                0
    PublicRecordsLast10Years               0
    PublicRecordsLast12Months              0
    RevolvingCreditBalance                 0
    BankcardUtilization                    0
    AvailableBankcardCredit                0
    TotalTrades                            0
    TradesNeverDelinquent (percentage)     0
    TradesOpenedLast6Months                0
    DebtToIncomeRatio                      0
    IncomeRange                            0
    IncomeVerifiable                       0
    StatedMonthlyIncome                    0
    TotalProsperLoans                      0
    TotalProsperPaymentsBilled             0
    OnTimeProsperPayments                  0
    ProsperPaymentsLessThanOneMonthLate    0
    ProsperPaymentsOneMonthPlusLate        0
    ProsperPrincipalBorrowed               0
    ProsperPrincipalOutstanding            0
    LoanOriginalAmount                     0
    MonthlyLoanPayment                     0
    PercentFunded                          0
    Recommendations                        0
    InvestmentFromFriendsCount             0
    InvestmentFromFriendsAmount            0
    Investors                              0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 106290 entries, 0 to 113936
    Data columns (total 59 columns):
    CreditGrade                            106290 non-null object
    Term                                   106290 non-null int64
    LoanStatus                             106290 non-null object
    BorrowerAPR                            106290 non-null float64
    BorrowerRate                           106290 non-null float64
    LenderYield                            106290 non-null float64
    EstimatedEffectiveYield                106290 non-null float64
    EstimatedLoss                          106290 non-null float64
    EstimatedReturn                        106290 non-null float64
    ProsperRating (numeric)                106290 non-null float64
    ProsperRating (Alpha)                  106290 non-null object
    ProsperScore                           106290 non-null float64
    ListingCategory (numeric)              106290 non-null int64
    BorrowerState                          106290 non-null object
    Occupation                             106290 non-null object
    EmploymentStatus                       106290 non-null object
    EmploymentStatusDuration               106290 non-null float64
    IsBorrowerHomeowner                    106290 non-null bool
    CurrentlyInGroup                       106290 non-null bool
    GroupKey                               106290 non-null object
    CreditScoreRangeLower                  106290 non-null float64
    CreditScoreRangeUpper                  106290 non-null float64
    FirstRecordedCreditLine                106290 non-null object
    CurrentCreditLines                     106290 non-null float64
    OpenCreditLines                        106290 non-null float64
    TotalCreditLinespast7years             106290 non-null float64
    OpenRevolvingAccounts                  106290 non-null int64
    OpenRevolvingMonthlyPayment            106290 non-null float64
    InquiriesLast6Months                   106290 non-null float64
    TotalInquiries                         106290 non-null float64
    CurrentDelinquencies                   106290 non-null float64
    AmountDelinquent                       106290 non-null float64
    DelinquenciesLast7Years                106290 non-null float64
    PublicRecordsLast10Years               106290 non-null float64
    PublicRecordsLast12Months              106290 non-null float64
    RevolvingCreditBalance                 106290 non-null float64
    BankcardUtilization                    106290 non-null float64
    AvailableBankcardCredit                106290 non-null float64
    TotalTrades                            106290 non-null float64
    TradesNeverDelinquent (percentage)     106290 non-null float64
    TradesOpenedLast6Months                106290 non-null float64
    DebtToIncomeRatio                      106290 non-null float64
    IncomeRange                            106290 non-null object
    IncomeVerifiable                       106290 non-null bool
    StatedMonthlyIncome                    106290 non-null float64
    TotalProsperLoans                      106290 non-null float64
    TotalProsperPaymentsBilled             106290 non-null float64
    OnTimeProsperPayments                  106290 non-null float64
    ProsperPaymentsLessThanOneMonthLate    106290 non-null float64
    ProsperPaymentsOneMonthPlusLate        106290 non-null float64
    ProsperPrincipalBorrowed               106290 non-null float64
    ProsperPrincipalOutstanding            106290 non-null float64
    LoanOriginalAmount                     106290 non-null int64
    MonthlyLoanPayment                     106290 non-null float64
    PercentFunded                          106290 non-null float64
    Recommendations                        106290 non-null int64
    InvestmentFromFriendsCount             106290 non-null int64
    InvestmentFromFriendsAmount            106290 non-null float64
    Investors                              106290 non-null int64
    dtypes: bool(3), float64(40), int64(7), object(9)
    memory usage: 46.5+ MB
    

## Univariate Exploration

> In this section, investigate distributions of individual variables. If
you see unusual points or outliers, take a deeper look to clean things up
and prepare yourself to look at relationships between variables.

Ok now well look at the different loan status




```python
df['LoanStatus'].value_counts()
```




    Current                   56566
    Completed                 33530
    Chargedoff                10632
    Defaulted                  3289
    Past Due (1-15 days)        806
    Past Due (31-60 days)       363
    Past Due (61-90 days)       313
    Past Due (91-120 days)      304
    Past Due (16-30 days)       265
    FinalPaymentInProgress      205
    Past Due (>120 days)         16
    Cancelled                     1
    Name: LoanStatus, dtype: int64




```python

df_historic = df[df["LoanStatus"] != "Current"]

df_historic["LoanStatus"].value_counts()
```




    Completed                 33530
    Chargedoff                10632
    Defaulted                  3289
    Past Due (1-15 days)        806
    Past Due (31-60 days)       363
    Past Due (61-90 days)       313
    Past Due (91-120 days)      304
    Past Due (16-30 days)       265
    FinalPaymentInProgress      205
    Past Due (>120 days)         16
    Cancelled                     1
    Name: LoanStatus, dtype: int64




```python
#Encode all completed loans as 1, and all delinquent, chargedoff, cancelled and defaulted loans as 0

df_historic["LoanStatus"] = (df_historic["LoanStatus"] == "Completed").astype(int)

df_historic["LoanStatus"][:10]
```

    C:\Users\twies\Anaconda3\lib\site-packages\ipykernel_launcher.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      This is separate from the ipykernel package so we can avoid doing imports until
    




    0     1
    11    1
    12    0
    15    0
    21    1
    23    0
    26    1
    27    1
    30    1
    33    1
    Name: LoanStatus, dtype: int32




```python
sb.countplot(df_historic["LoanStatus"]);


```


![png](output_26_0.png)



```python
df_historical["LoanStatus"].mean()
```




    0.6743222588689567



So 67% of loans are actually completed, leaving the other 32% defaulted

## Bivariate Exploration

> In this section, investigate relationships between pairs of variables in your
data. Make sure the variables that you cover here have been introduced in some
fashion in the previous section (univariate exploration).


```python
sb.set_context({"figure.figsize": (15, 7.5)})
sb.barplot(x="BorrowerState", y="LoanStatus", data=df_historic);
```

    C:\Users\twies\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    


![png](output_30_1.png)



```python
al, dc = df_historical[df_historical["BorrowerState"] == "AL"], df_historical[df_historical["BorrowerState"] == "DC"]

1 - al["LoanStatus"].mean(), 1 - dc["LoanStatus"].mean()
```




    (0.42205323193916355, 0.22043010752688175)



Interestingly, Alambamas defaulted 42% of the time, while Northern Virginians defaulted 22% of the time


```python
df_historic.replace(to_replace={"ListingCategory (numeric)": {0: "Unknown", 1: "Debt", 2: "Reno", 3: "Business", 4: "Personal",
                                                                5: "Student", 6: "Auto", 7: "Other", 8: "Baby", 9: "Boat", 
                                                                10: "Cosmetic", 11: "Engagement", 12: "Green", 13: "Household",
                                                                14: "LargePurchase", 15: "Medical", 16: "Motorcycle", 17: "RV",
                                                                18: "Taxes", 19: "Vacation", 20: "Wedding"}}, inplace=True)

df_historic.rename(index=str, columns={"ListingCategory (numeric)": "ListingCategory"}, inplace=True)

df_historic["ListingCategory"][:10]
```

    C:\Users\twies\Anaconda3\lib\site-packages\pandas\core\generic.py:5821: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      regex=regex)
    C:\Users\twies\Anaconda3\lib\site-packages\pandas\core\frame.py:3781: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      return super(DataFrame, self).rename(**kwargs)
    




    0       Unknown
    11      Unknown
    12         Debt
    15    Household
    21      Unknown
    23      Medical
    26         Debt
    27         Debt
    30      Wedding
    33        Other
    Name: ListingCategory, dtype: object




```python
sb.set_context({"figure.figsize": (17, 7.5)})
sb.barplot(x="ListingCategory", y="LoanStatus", data=df_historic);
```

    C:\Users\twies\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    


![png](output_34_1.png)


Lets look a the credit scores



```python
fig = plt.figure()

ax1 = fig.add_subplot(221)
sb.barplot(x="ProsperRating (numeric)", y="LoanStatus", data=df_historic)

ax2 = fig.add_subplot(222)
sb.barplot(x="ProsperScore", y="LoanStatus", data=df_historic)

ax3 = fig.add_subplot(223)
sb.barplot(x="CreditScoreRangeLower", y="LoanStatus", data=df_historic)

ax4 = fig.add_subplot(224)
sb.barplot(x="CreditScoreRangeUpper", y="LoanStatus", data=df_historic)
```

    C:\Users\twies\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <matplotlib.axes._subplots.AxesSubplot at 0x29f8a3059b0>




![png](output_36_2.png)


so higher score means lower default rate


quick look at interest rates


```python
sb.distplot(df_historic["BorrowerRate"])

```

    C:\Users\twies\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <matplotlib.axes._subplots.AxesSubplot at 0x29f89dab748>




![png](output_39_2.png)


so lets compare rate, default status, and credit score


```python
sb.boxplot(x="ProsperScore", y='BorrowerRate', hue='LoanStatus', data=df_historic)

```




    <matplotlib.axes._subplots.AxesSubplot at 0x29f8a3cb630>




![png](output_41_1.png)


so this sort of says higher score gets you a better rate
